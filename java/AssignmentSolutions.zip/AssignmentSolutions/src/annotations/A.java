package annotations;

public class A {

	@Deprecated
	int id;

}
