package exceptions;

public class MyThreadException extends RuntimeException {

}
