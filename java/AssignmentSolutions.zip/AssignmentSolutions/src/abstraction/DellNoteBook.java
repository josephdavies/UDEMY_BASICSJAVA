package abstraction;

public class DellNoteBook extends DellLaptop {

	@Override
	public void click() {
		System.out.println("Scroll Method From DellNoteBook");
	}

}
