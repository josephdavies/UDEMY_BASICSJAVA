package abstraction;

public interface TouchScreenLaptop {
	void scroll();

	void click();
}
