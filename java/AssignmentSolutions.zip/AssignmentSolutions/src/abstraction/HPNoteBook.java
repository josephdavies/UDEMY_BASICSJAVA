package abstraction;

public class HPNoteBook extends HPLaptop {

	@Override
	public void click() {
		System.out.println("Scroll Method From HPNoteBook");
	}

}
