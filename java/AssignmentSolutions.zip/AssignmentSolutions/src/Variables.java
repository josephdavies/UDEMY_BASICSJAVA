public class Variables {

	public static void main(String[] args) {
		int i = 10;
		float f = 20.54f;
		char c = 'X';
		String s = "I am the best";

		System.out.println(i);
		System.out.println(f);
		System.out.println(c);
		System.out.println(s);

	}

}
